Thank you for downloading a SummitType Font!

Please refer to the license included with the font zip file to learn about 
how you can use the font and any restrictions there may be.

SummitType Fonts is a division of Summitsoft Corporation, a leading software 
developer for small business, productivity and utilities. Summitsoft offers 
font management software and other font software bundles on its website.


**************************************************************************

Get more free commercial use fonts for your Windows computer here:
http://www.summitsoftcorp.com/fonts/free-fonts-download.html

Get more free commercial use fonts for your Mac computer here:
http://www.macwareinc.com/freefont.asp

**************************************************************************

To learn more about Summitsoft software (Windows software), please visit:
http://www.summitsoftcorp.com/

To learn more about Macware software (Mac software), please visit:
http://www.macwareinc.com/

**************************************************************************

If you have any questions or comments, you can contact Summitsoft here:
sales@summitsoftcorp.com

Or, for support questions, please visit our support center:
http://www.summitsoftcorp.com/support/help-desk-center.html


Thank you,

SummitType Fonts
